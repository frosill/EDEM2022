'''
INVOCAMOS A LA FUNCION DEL VOLUMEN DE UN CILINDRO
'''
from Funciones.calculo_volumen import volumen_cilindro

#Tendremos que pasarle como parámetros el radio de la base y la altura
volumen_cilindro(2,2)