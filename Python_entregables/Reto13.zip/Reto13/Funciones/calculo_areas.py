'''
Reto 13: Escribe una función que calcule el área de un triángulo, recibiendo la altura y la base como parámetros y otra función que calcule el área de un círculo recibiendo el radio del mismo.
'''
'''
AREA TRIANGULO
'''

def area_triangulo(base: float, altura: float) -> float:

  return print(base*altura/2)

'''
AREA CIRCULO
'''

from math import pi

def area_circulo(radio: float) -> float:
  
  return print(pi*radio**2)
  