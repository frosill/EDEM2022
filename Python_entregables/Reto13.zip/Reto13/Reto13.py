from Funciones.calculo_areas import area_triangulo
from Funciones.calculo_areas import area_circulo

area_triangulo(2,2) #Comprobamos que funciona calculando el area de un triangulo base = 2, altura = 2
area_circulo(1) #Comprobamos que funciona calculando el area de una circunferencia de radio = 1